var LANG = window.LANG || {};

// @import_i18n: src/i18n/en.json
LANG["en"] = {
	"list": {
		"name": "Name"
	}
};

// @import_i18n: src/i18n/ja.json
LANG["ja"] = {
	"list": {
		"name": "名前"
	}
};

// @import_i18n: src/i18n/ko.json
LANG["ko"] = {
	"list": {
		"name": "이름"
	}
};