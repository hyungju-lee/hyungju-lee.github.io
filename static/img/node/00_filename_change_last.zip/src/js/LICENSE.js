/** @license
	Copylight Sample
*/