'use strict';

// libs

var selector = function(s, d) {
	if (arguments.length > 1 && !d) {
		return null;
	}
	return (d || document).querySelector(s);
};

HTMLElement.prototype.hasClass = function(className) {
	if (this.classList) {
		return this.classList.contains(className);
	} else {
		return (-1 < this.className.indexOf(className));
	}
};

HTMLElement.prototype.addClass = function(className) {
	if (this.classList) {
		this.classList.add(className);
	} else if (!this.hasClass(className)) {
		var classes = this.className.split(' ');
		classes.push(className);
		this.className = classes.join(' ');
	}
	return this;
};

HTMLElement.prototype.removeClass = function(className) {
	if (this.classList) {
		this.classList.remove(className);
	} else {
		var classes = this.className.split(' ');
		classes.splice(classes.indexOf(className), 1);
		this.className = classes.join(' ');
	}
	return this;
};

HTMLElement.prototype.css = function(property, value) {
	try {
		this.style = property + ':' + value;
	} catch (e) {}
};

HTMLElement.prototype.on = HTMLDocument.prototype.on = function(events, handler) {
	var ele = this;
	events.split(',').forEach(function(eventName) {
		ele.addEventListener(eventName, handler, false);
	});
};

HTMLElement.prototype.off = HTMLDocument.prototype.off = function(events, handler) {
	var ele = this;
	events.split(',').forEach(function(eventName) {
		ele.removeEventListener(eventName, handler, false);
	});
};