'use strict';

$(document).ready(function(window, document, undefined) {
	console.log('load complete!!');
}(window, document));

// if No js library(ex. zepto, jQuery)
/*document.addEventListener('DOMContentLoaded', function(event) {
	console.log('load complete!!');
});*/