$(document).ready(function(){
    //init
    var promoName = '';
    var promoType = 0;
    var couponType = '';
    var templateType = 0;
    var templateTypeOnline = 0;
    var templateTypeOffline = 0;
    var templateBrand = '';
    var secNum = 0;
    var couNum = 0;
    var notiNum = 0;
    var upperStr = '';
    var secStr = '';
    var minType = 0;
    var srcType = '';
    booleanDb = false;
    arrayChecked = [false, false, false];
    filterOn = ['', '', ''];
    filterDisplay = [' style="display:none"', ' style="display:none"', ' style="display:none"'];

    // $('input[type=radio]').attr('disabled','');
    // $('.generate').hide();
    // $('.option:nth-child(3),.option:nth-child(4),.option:nth-child(5)').click(function(){
    // 	if($('#sectionNum').val() == '') {
    // 		alert('섹션수를 입력하세요');
    // 	}
    //   else {}
    // });
    // $('.option:nth-child(4),.option:nth-child(5)').click(function(){
    // 	if( couponType == '') {
    // 		alert('프로모션 유형을 선택하세요');
    // 	}
    //   else {}
    // });

    $('.wrap_left > .option:nth-child(-n+5) > input').attr('disabled','');
    $('.option:first-child > input').removeAttr('disabled').parent().addClass('noAlert');
    $('.option > input').on('input',function(){
        if($(this).attr('type') == 'radio') {
            if($(this).attr('name') == 'promotionType'){
                if($(this).val() == 0){
                    $(this).parent().next().addClass('noAlert').children('input').removeAttr('disabled');
                }
                else {
                    $(this).parent().next().addClass('noAlert').children('input').attr('disabled','');
                    $(this).parent().next().next().addClass('noAlert').children('input').removeAttr('disabled');
                }
            }
            else {
                $(this).parent().next().addClass('noAlert').children('input').removeAttr('disabled');
            }
        }
        else {
            if($(this).val() == '') {

            }
            else {
                $(this).parent().next().addClass('noAlert').children('input').removeAttr('disabled');
            }
        }
        if($('.couponType').next().hasClass('noAlert')) {
            $('.option.db input').removeAttr('disabled');
            $('.option.db').addClass('noAlert');
        }
    });
    $('.wrap_left > .option:nth-child(-n+5), .option.db').on('click', function(){
        if($(this).hasClass('noAlert')) {

        }
        else {
            alert('상단 필수 항목값을 입력해주세요');
        }
    });
    $('input#boolean_db').on('input',function(){
        booleanDb = $(this).prop('checked');
        if(booleanDb) {
            $('.option.db').show();
        }
        else {
            $('.option.db').hide();
        }
    });
    $('input[name=promotionType]').on('input', function(){
        promoType = $('input[name=promotionType]:checked').val();
        if(promoType == 1){
            $('.couponType').hide();
            $('.couponNum').show();
            $('.couponNum').prev().show();
        }
        else{
            $('.couponType').show();
            couponType = 0;
        }
    });
    $('input[name=couponType]').on('input', function(){
        couponType = $('input[name=couponType]:checked').val();
        if(couponType == 0){
            $('.couponNum').hide();
            $('.couponNum').prev().hide();
        }
        else{
            $('.couponNum').show();
            $('.couponNum').prev().show();
        }
    });
    $('input[name=templateType]').on('input', function(){
        templateType = $('input[name=templateType]:checked').val();
        //console.log(templateType);
        if (templateType == 0) {
            $('.option.offline').hide();
            $('.option.online').hide();
            $('.option.preview').hide();
            $('.option.button').hide();
        }
        else if (templateType == 1) {
            $('.option.offline').hide();
            $('.option.online').show();
            $('.option.preview').show();
            $('.option.button').show();
        }
        else {
            $('.option.offline').show();
            $('.option.online').hide();
            $('.option.preview').show();
            $('.option.button').show();
        }
    });
    $('input[name=templateOnline]').on('input', function(){
        templateTypeOnline = $('input[name=templateOnline]:checked').val();
        var ment1 = '쿠폰 다운로드하기',
            ment2 = '가맹점에서 결제 시, 결제 수단으로 [PAYCO] 선택하기',
            ment3 = '$브랜드명$ 에서 쿠폰번호 등록하기',
            ment4 = '쿠폰번호 복사 후, 결제 시 쿠폰코드 입력하기',
            ment5 = '결제 시, 결제 수단으로 [PAYCO] 선택하기',
            ment6 = '쿠폰 적용 후, 결제하기',
            ment7 = '결제 시, 쿠폰 사용하기',
            ment8 = '혜택 적용 사항 확인 후 결제하기';
        if (templateTypeOnline == 1) {
            $('.template_brand').show();
        }
        else {
            $('.template_brand').hide();
        }
        switch(templateTypeOnline) {
            case "0":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment2);
                $('.lst_guide li').eq(2).text('3. '+ment6);
                $('.lst_guide li').eq(2).show();
                break;
            case "1":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment3);
                $('.lst_guide li').eq(2).text('3. '+ment7);
                $('.lst_guide li').eq(2).show();
                break;
            case "2":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment4);
                $('.lst_guide li').eq(2).text('3. '+ment6);
                $('.lst_guide li').eq(2).show();
                break;
            case "3":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment5);
                $('.lst_guide li').eq(2).text('3. '+ment6);
                $('.lst_guide li').eq(2).show();
                break;
            case "4":
                $('.lst_guide li').eq(0).text('1. '+ment5);
                $('.lst_guide li').eq(1).text('2. '+ment8);
                $('.lst_guide li').eq(2).hide();
                break;
            default:
                break;
        }
    });
    $('input[name=templateOffline]').on('input', function(){
        templateTypeOffline = $('input[name=templateOffline]:checked').val();
        var ment1 = '쿠폰 다운로드하기',
            ment2 = '매장 방문하기',
            ment3 = '매장 방문 후, 계산 시 직원에게 쿠폰 보여주기',
            ment4 = '매장 방문 후, PAYCO 앱으로 결제하기',
            ment5 = '키오스크 결제 시 [PAYCO 앱 → QR코드] 실행',
            ment6 = 'PAYCO 앱으로 결제하기',
            ment7 = '키오스크에서 PAYCO 앱으로 결제',
            ment8 = '직원,키오스크를 통해 PAYCO 앱으로 결제하기',
            ment9 = '할인 적용된 금액을 PAYCO로 결제하기',
            ment10 = '할인 적용 금액 확인 후, 현금/카드 결제',
            ment11 = '결제 완료 (결제 시 할인 자동 적용)',
            ment12 = '키오스크에서 쿠폰 사용하기',
            ment13 = '직원 또는 키오스크를 통해 쿠폰 사용하기',
            ment14 = '매장 방문 후, 직원에게 쿠폰 보여주기',
            ment15 = '결제 완료 (할인 자동 적용)';
        switch(templateTypeOffline) {
            case "0":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment3);
                $('.lst_guide li').eq(2).text('3. '+ment9);
                $('.lst_guide li').eq(2).show();
                break;
            case "1":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment3);
                $('.lst_guide li').eq(2).text('3. '+ment10);
                $('.lst_guide li').eq(2).show();
                break;
            case "2":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment4);
                $('.lst_guide li').eq(2).text('3. '+ment11);
                $('.lst_guide li').eq(2).show();
                break;
            case "3":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment2);
                $('.lst_guide li').eq(2).text('3. '+ment12);
                $('.lst_guide li').eq(2).show();
                break;
            case "4":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment2);
                $('.lst_guide li').eq(2).text('3. '+ment13);
                $('.lst_guide li').eq(2).show();
                break;
            case "5":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment14);
                $('.lst_guide li').eq(2).hide();
                break;
            case "6":
                $('.lst_guide li').eq(0).text('1. '+ment1);
                $('.lst_guide li').eq(1).text('2. '+ment5);
                $('.lst_guide li').eq(2).text('3. '+ment11);
                $('.lst_guide li').eq(2).show();
                break;
            case "7":
                $('.lst_guide li').eq(0).text('1. '+ment2);
                $('.lst_guide li').eq(1).text('2. '+ment6);
                $('.lst_guide li').eq(2).text('3. '+ment11);
                $('.lst_guide li').eq(2).show();
                break;
            case "8":
                $('.lst_guide li').eq(0).text('1. '+ment2);
                $('.lst_guide li').eq(1).text('2. '+ment4);
                $('.lst_guide li').eq(2).text('3. '+ment15);
                $('.lst_guide li').eq(2).show();

                break;
            case "9":
                $('.lst_guide li').eq(0).text('1. '+ment2);
                $('.lst_guide li').eq(1).text('2. '+ment8);
                $('.lst_guide li').eq(2).text('3. '+ment15);
                $('.lst_guide li').eq(2).show();
                break;
            default:
                break;
        }
    });
    $('input#templateBrand').on('input', function(){
        templateBrand = $(this).val();
    });
    $('input[name=fixedType]').on('input', function(){
        fixedType = $(this).val();
        if(fixedType == 0) {
            $('.db_price').hide();
            $('.db_rate').show();
        }
        else {
            $('.db_price').show();
            $('.db_rate').hide();
        }
    })
    $('input[name=dbFilter]').on('input', function(){
        arrayChecked[$(this).parent().index()] = $(this).prop('checked');
        filterOn = ['', '', ''];
        filterOn[arrayChecked.lastIndexOf(true)] = 'class="on" ';
        if($(this).prop('checked') == true) {
            filterDisplay[$(this).parent().index()] = '';
        }
        else {
            filterDisplay[$(this).parent().index()] = ' style="display:none"';
        }
    });
    $('#sectionNum').on('input', function(){
        secNum = $(this).val();
        secLength = $('.wrap_right .option').length;
        optStr = '';
        if(secLength < secNum) {
            for(s=secLength;s<secNum+1;s++){
                if (s == secNum) {
                    break;
                }
                var n = s + 1;
                optionBlock(n);
            }
            $('.wrap_right').append(optStr);
        }
        else if(secLength > secNum) {
            for(sD=1;sD<=secLength-secNum;sD++){
                $('.wrap_right .option:last-child').remove();
            }
        }
        $('.couponNum').on('input', function(){
            couNum = $(this).val();
            couLength = $(this).siblings('.sub_coupon').find('div').length;
            couSecUncut = $(this).attr('id');
            couSec = couSecUncut.replace("couponNum","");
            couStr = '';
            if(couLength < couNum) {
                for(c=couLength;c<couNum+1;c++){
                    if(c == couNum){
                        break;
                    }
                    var d = c + 1;
                    couponBlock(d,couSec);
                }
                $(this).siblings('.sub_coupon').append(couStr);
            }
            else if(couLength > couNum) {
                for(cD=1;cD<=couLength-couNum;cD++) {
                    $(this).siblings('.sub_coupon').find('div:last-child').remove();
                }
            }
        });
        $('.linkNum').on('input', function(){
            lnkNum = $(this).val();
            lnkLength = $(this).siblings('.sub_link').find('div').length;
            lnkSecUncut = $(this).attr('id');
            lnkSec = lnkSecUncut.replace("linkNum","");
            lnkStr = '';
            if(lnkLength < lnkNum) {
                for(l=lnkLength;l<lnkNum+1;l++){
                    if(l == lnkNum){
                        break;
                    }
                    var k = l + 1;
                    linkBlock(k,lnkSec);
                }
                $(this).siblings('.sub_link').append(lnkStr);
            }
            else if(lnkLength > lnkNum) {
                for(L=1;L<=lnkLength-lnkNum;L++) {
                    $(this).siblings('.sub_link').find('div:last-child').remove();
                }
            }
        });
    });
    function optionBlock(n) {
        optStr += '<div class="option opt'+n+'">',
            optStr += '	<h2 style="display: inline">섹션'+n+'</h2>',
            optStr += '	<label for="couponNum'+n+'">쿠폰수</label>',
            optStr += '	<input type="number" class="couponNum" id="couponNum'+n+'" min="0">',
            optStr += '	<label for="linkNum'+n+'">링크수</label>',
            optStr += '	<input type="number" class="linkNum" id="linkNum'+n+'" min="0"><br>',
            optStr += '	<label for="secHeight'+n+'">(750px기준)섹션높이</label>',
            optStr += '	<input type="number" class="secHeight" id="secHeight'+n+'" min="0" placeholder="px">',
            optStr += ' <div class="sub_coupon"></div>',
            optStr += ' <div class="sub_link"></div>',
            optStr += '</div>';
    }
    function couponBlock (d,cousec) {
        couStr += '<div class="sub_option'+d+'">',
            couStr += '	<h3>쿠폰'+d+'</h3>',
            couStr += ' <br><label for="prmtId_'+couSec+'_'+d+'">프로모션ID</label>',
            couStr += ' <input type="number" class="prmtId" id="prmtId_'+couSec+'_'+d+'" min="0">',
            couStr += ' <label for="couponId_'+couSec+'_'+d+'">쿠폰ID</label>',
            couStr += ' <input type="number" class="couponId" id="couponId_'+couSec+'_'+d+'" min="0">',
            couStr += ' <br><label for="couponTxt_'+couSec+'_'+d+'">쿠폰텍스트</label>',
            couStr += ' <input type="text" class="couponTxt" id="couponTxt_'+couSec+'_'+d+'">',
            couStr += ' <br><br><label for="couponTop_'+couSec+'_'+d+'">top</label>',
            couStr += ' <input type="number" class="couponTop" id="couponTop_'+couSec+'_'+d+'" placeholder="px">',
            couStr += ' <br><label for="couponLeft_'+couSec+'_'+d+'">left</label>',
            couStr += ' <input type="number" class="couponLeft" id="couponLeft_'+couSec+'_'+d+'" placeholder="px">',
            couStr += ' <label for="couponRight_'+couSec+'_'+d+'">right</label>',
            couStr += ' <input type="number" class="couponright" id="couponRight_'+couSec+'_'+d+'" placeholder="px">',
            couStr += ' <br><label for="couponWidth_'+couSec+'_'+d+'">width</label>',
            couStr += ' <input type="number" class="couponWidth" id="couponWidth_'+couSec+'_'+d+'" placeholder="px">',
            couStr += ' <label for="couponHeight_'+couSec+'_'+d+'">height</label>',
            couStr += ' <input type="number" class="couponHeight" id="couponHeight_'+couSec+'_'+d+'" placeholder="px">',
            couStr += ' <br>';
        couStr += '</div>';
    }
    function linkBlock(k,lnkSec) {
        lnkStr += '<div class="sub_option'+k+'">',
            lnkStr += '	<h3>링크'+k+'</h3>',
            lnkStr += ' <label for="url_'+lnkSec+'_'+k+'">URL</label>',
            lnkStr += ' <input type="text" class="url" id="url_'+lnkSec+'_'+k+'">',
            lnkStr += ' <br><label for="lnkTxt_'+lnkSec+'_'+k+'">텍스트</label>',
            lnkStr += ' <input type="text" class="lnkTxt" id="lnkTxt_'+lnkSec+'_'+k+'">',
            lnkStr += ' <br><br><label for="lnkTop_'+lnkSec+'_'+k+'">top</label>',
            lnkStr += ' <input type="number" class="lnkTop" id="lnkTop_'+lnkSec+'_'+k+'" placeholder="px">',
            lnkStr += ' <br><label for="lnkLeft_'+lnkSec+'_'+k+'">left</label>',
            lnkStr += ' <input type="number" class="lnkLeft" id="lnkLeft_'+lnkSec+'_'+k+'" placeholder="px">',
            lnkStr += ' <label for="lnkRight_'+lnkSec+'_'+k+'">right</label>',
            lnkStr += ' <input type="number" class="lnkRight" id="lnkRight_'+lnkSec+'_'+k+'" placeholder="px">',
            lnkStr += ' <br><label for="lnkWidth_'+lnkSec+'_'+k+'">width</label>',
            lnkStr += ' <input type="number" class="lnkWidth" id="lnkWidth_'+lnkSec+'_'+k+'" placeholder="px">',
            lnkStr += ' <label for="lnkHeight_'+lnkSec+'_'+k+'">height</label>',
            lnkStr += ' <input type="number" class="lnkHeight" id="lnkHeight_'+lnkSec+'_'+k+'" placeholder="px">',
            lnkStr += '</div>';
    }
    //사용여부 판단 필요
    // $('#notiNum').on('input', function(){
    // 	notiNum = $(this).val();
    // });
    $('.generate').click(function(){
        var promoName = $('#promotion_name').val(),
            promoType = $('input[name=promotionType]:checked').val(),
            couponType = $('input[name=couponType]:checked').val(),
            secNum = $('#sectionNum').val(),
            minType = $(this).index();
        if(promoType == 1){
            couponType = 0;
        }

        //upperStructure
        if(minType == 0){
            srcType = 'img';
            upperStr = '';
            var bName = promoName.toUpperCase();
            if(promoType == 0){
                topStr(0,'PAYCO X '+ bName);
            }
            else{
                var bNameSplit = bName.split('_');
                var bName = bNameSplit[0];
                topStr(0,bName);
            }
        }
        else if(minType == 1){
            srcType = 'https://image.toast.com/aaaaac/paycoNoti';
            if(couponType == 0){
                upperStr = '';
                topStr(2, false);
            }
            else{
                upperStr = '';
                topStr(1, false);
            }
        }

        function topStr(mil, name){
            if(mil == 0){
                upperStr +='<!DOCTYPE html>',
                    upperStr +='\n<html lang="ko">',
                    upperStr +='\n<head>',
                    upperStr +='\n<meta charset="utf-8">',
                    upperStr +='\n<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">',
                    upperStr +='\n<!-- [D] 숫자의 특정 갯수 이상시 폰번호 인식을 제거하는 메타태그 -->',
                    upperStr +='\n<meta name="format-detection" content="telephone=no">',
                    upperStr +='\n<link rel="stylesheet" type="text/css" href="http://www.payco.com/share/css/app_event.css">',
                    upperStr +='\n<title>'+name+'</title>',
                    upperStr +='\n</head>',
                    upperStr +='\n<body>',
                    upperStr +='\n<div id="wrap">',
                    upperStr +='\n<div id="container">',

                    upperStr +='\n<div class="event_wrap" style="padding:0">',
                    upperStr +='\n<div class="e_cont" style="padding:0">';
            }
            else if(mil == 1){
                upperStr +='\n<div id="wrap">',
                    upperStr +='\n<div id="container">',

                    upperStr +='\n<div class="event_wrap" style="padding:0">',
                    upperStr +='\n<div class="e_cont" style="padding:0">';
            }
        }
        upperStr +='\n<!--이벤트 영역-->',
            upperStr +='\n<div class="payco_evt_wrap">',
            upperStr +='\n<style scoped="scoped">',
            upperStr +='\n@import url(http://fonts.googleapis.com/earlyaccess/notosanskr.css);',
            upperStr +='\nhtml,body{width:100%;height:100%;margin:0;padding:0}',
            upperStr +='\nbody,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,p,th,td,input,select,textarea,button{margin:0;padding:0;-webkit-text-size-adjust:none}',
            upperStr +='\ndl,ul,ol,menu,li{margin:0;padding:0;list-style:none}',
            upperStr +='\nem{font-style:normal}',
            upperStr +='\n.blind{overflow:hidden;position:absolute;top:-999px;left:-999px;width:0;height:0;font-size:0;line-height:0;white-space:nowrap}',
            upperStr +="\n.payco_evt_bx{overflow:hidden;position:relative;background:#dbd5c5;font-family:'Noto Sans KR','Apple SD Gothic Neo',sans-serif;}",
            upperStr +='\n.payco_evt_bx .sec{position:relative;width:100%;max-width:100%;-webkit-box-sizing:border-box;box-sizing:border-box}',
            upperStr +='\n.payco_evt_bx .sec img{width:100%;max-width:100%}',
            upperStr +='\n.btn{display:inline-block;overflow:hidden;position:absolute;line-height:999px}';
        var cn = 0;
        var ln = 0;
        for (i=0;i<secNum+1;i++){
            var ii = i + 1;
            var cc = $('#couponNum'+ii).val();
            var sH = $('#secHeight'+ii).val();
            var upperStr = upperStr;
            var dn = cn;
            cn = Number(cn) + Number(cc);
            if(promoType == 0){
                if(couponType == 0){
                    couponCss(0,false,false);
                }
                else{
                    couponCss(cc,sH,ii);
                }
            }
            else {
                couponCss(cc,sH,ii);
            }
        };
        for (i=0;i<secNum+1;i++){
            var ii = i + 1;
            var ll = $('#linkNum'+ii).val();
            var sH = $('#secHeight'+ii).val();
            var upperStr = upperStr;
            var mn = ln;
            ln = Number(ln) + Number(ll);
            linkCss(ll,sH,ii);
        };
        upperStr +='\n.sec_noti{padding:50px 6.67%;background:#fff;font-size:0;text-align:left;-webkit-box-sizing:border-box;box-sizing:border-box}',
            upperStr +='\n.sec_noti .tit{margin-bottom:20px;font-size:20px;color:#000;font-weight:700}',
            upperStr +='\n.lst_noti li{position:relative;margin-top:9px;padding-left:10px;font-size:12px;font-weight:400;color:#424242;line-height:17px;list-style:none}',
            upperStr +="\n.lst_noti li:before{position:absolute;top:7px;left:1px;width:2px;height:2px;background:#4b4a38;content:''}",
            upperStr +='\n.lst_noti li:first-child{margin-top:0}';
        templateCss(templateType);
        popupStr(couponType);
        dbStr(booleanDb);
        upperStr +='\n</style>',
            upperStr +='\n<div class="payco_evt_bx">';
        function percentage (x,h) {
            var x = x;
            x = (x / h) * 100;
            x = x.toFixed(2);
            var xSub = x.split('.');
            if(xSub[1] == '00') {
                x = xSub[0];
            }
            else {
                var xSubLast = xSub[1];
                xSubLast = String(xSubLast);
                xSubLast = xSubLast.substring(1,2);
                if(xSubLast == 0) {
                    xSub[1] = xSub[1].replace('0','');
                    var x = xSub.join('.');
                }
            }
            return x+'%';
        }
        function couponCss(n,hh,m) {
            for(t=0;t<n;t++){
                var tt = t + 1;
                var tt2 = Number(dn) + Number(tt);
                if(tt2 == 1){
                    var tt2 = '';
                }
                else{
                    var tt2 = tt2;
                }
                var cTop = $('#couponTop_'+m+'_'+tt).val();
                cTop = percentage(cTop,hh);
                var cLeft = $('#couponLeft_'+m+'_'+tt).val();
                if(cLeft == '') {
                    cLeft = '';
                }
                else {
                    cLeft = 'left:'+percentage(cLeft,750)+';';
                }
                var cRight = $('#couponRight_'+m+'_'+tt).val();
                if(cRight == '') {
                    cRight = '';
                }
                else {
                    cRight = 'right:'+percentage(cRight,750)+';';
                }
                var cWidth = $('#couponWidth_'+m+'_'+tt).val();
                cWidth = percentage(cWidth,750);
                var cHeight = $('#couponHeight_'+m+'_'+tt).val();
                cHeight = percentage(cHeight,hh);
                upperStr += '\n.btn.btn_coupon'+tt2+'{top:'+cTop+';'+cLeft+cRight+'width:'+cWidth+';height:'+cHeight+'}';
                if(t == n){
                    break;
                }
            }
        }
        function linkCss(n,hh,m) {
            for(t=0;t<n;t++){
                var tt = t + 1;
                var tt2 = Number(mn) + Number(tt);
                if(tt2 == 1){
                    var tt2 = '';
                }
                else{
                    var tt2 = tt2;
                }
                var lTop = $('#lnkTop_'+m+'_'+tt).val();
                lTop = percentage(lTop,hh);
                var lLeft = $('#lnkLeft_'+m+'_'+tt).val();
                if(lLeft == '') {
                    lLeft = ''
                }
                else {
                    lLeft = 'left:'+percentage(lLeft,750)+';';
                }
                var lRight = $('#lnkRight_'+m+'_'+tt).val();
                if(lRight == '') {
                    lRight = ''
                }
                else {
                    lRight = 'right:'+percentage(lRight,750)+';';
                }
                var lWidth = $('#lnkWidth_'+m+'_'+tt).val();
                lWidth = percentage(lWidth,750);
                var lHeight = $('#lnkHeight_'+m+'_'+tt).val();
                lHeight = percentage(lHeight,hh);
                upperStr += '\n.btn.btn_link'+tt2+'{top:'+lTop+';'+lLeft+lRight+'width:'+lWidth+';height:'+lHeight+'}';
                if(t == n){
                    break;
                }
            }
        }
        function templateCss(tS) {
            var templateColor = $('#templateBtnColor').val();
            if(tS == 0) {
                return false;
            }
            else {
                upperStr +='\n/*template*/';
                upperStr +='\n.sec_guide{padding:45px 25px;background-color:#fff}';
                upperStr +='\n.sec_guide .tit_wrap{position:relative}';
                upperStr +="\n.sec_guide .tit_wrap:after{display:block;position:absolute;top:50%;right:0;width:100%;height:1px;background-color:#333;content:''}";
                upperStr +='\n.sec_guide .tit{display:inline-block;position:relative;z-index:1;padding-right:7px;background-color:#fff;font-size:20px;line-height:29px;font-weight:bold;color:#333}';
                upperStr +='\n.sec_guide .lst_guide{margin-top:23px;margin-left:5px}';
                upperStr +='\n.sec_guide .lst_guide li{margin-top:13px;font-size:15px;line-height:20px;font-weight:bold;color:#333}';
                upperStr +='\n.sec_guide .btn{display:block;position:static;margin-top:15px;padding:21px 0;background-color:#fa2828;font-size:18px;font-weight:bold;line-height:18px;color:#fff;text-align:center;box-sizing:border-box;letter-spacing:-0.5px}';
                upperStr +='\n.sec_guide .btn:first-of-type{margin-top:35px}';
                upperStr +='\n.sec_guide .btn_color2{background-color:#000}';
                upperStr +='\n.sec_guide .btn_color3{background-color:#4a90e2}';
                //btn_color4
                if(templateColor == ''){
                }
                else {
                    upperStr +='\n.sec_guide .btn_color4{background-color:#'+templateColor+'}';
                }
                upperStr +='\n.sec_guide .btn_type2{padding:18px 0;border:2px solid #fa2828;background-color:#fff;color:#fa2828}';
                upperStr +='\n.sec_guide .btn_qrcode,.sec_guide .btn_barcode{padding:18px 0;background-color:#212632}';
                upperStr +="\n.sec_guide .btn_qrcode:before,.sec_guide .btn_barcode:before{display:inline-block;overflow:hidden;background-repeat:no-repeat;background-size:100% auto;line-height:999px;vertical-align:middle;content:''}";
                upperStr +='\n.sec_guide .btn_qrcode:before{width:18px;height:18px;margin-right:13px;margin-top:-5px;background-image:url(https://image.toast.com/aaaaac/paycoNoti/ico_qrcode.png)}';
                upperStr +='\n.sec_guide .btn_barcode:before{width:20px;height:15px;margin-right:9px;margin-top:-6px;background-image:url(https://image.toast.com/aaaaac/paycoNoti/ico_barcode.png)}';
                upperStr +='\n.sec_noti{padding:45px 25px;background:#fff;font-size:0;text-align:left;-webkit-box-sizing:border-box;box-sizing:border-box}';
                upperStr +='\n.sec_guide,.sec_noti{border-top:1px solid rgba(0,0,0,0.2)}/* 위에 오는 컨텐츠의 배경색이 흰색인 경우에만 기본 선색 적용, 다른 배경색 컨텐츠 다음으로 오게 될 경우 해당 영역 제거 */';
            }
        }
        function popupStr(il) {
            if(il == 0){
                return false;
            }
            else{
                upperStr +='\n/* popup */',
                    upperStr +='\n.dimmed{position:fixed;top:0;right:0;bottom:0;left:0;z-index:100;width:100%;height:100%;background:rgba(0,0,0,0.8)}',
                    upperStr +='\n.ly_pop{position:fixed;top:50%;left:50%;z-index:100;width:285px;padding:0 10px 55px;background:#fff;-webkit-box-sizing:border-box;box-sizing:border-box;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);text-align:center}',
                    upperStr +='\n.ly_popbx{display:-webkit-box;display:flex;-webkit-box-flex:1;flex:1;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;-webkit-box-sizing:border-box;box-sizing:border-box;min-height:145px}',
                    upperStr +='\n.ly_popin{display:block}',
                    upperStr +='\n.ly_pop h2{padding:34px 0 6px;font-size:19px;color:#000;letter-spacing:-1px;line-height:25px}',
                    upperStr +='\n.ly_pop .ly_tit{display:inline}',
                    upperStr +='\n.ly_pop .tx_desc{padding:9px 13px 23px;-webkit-box-sizing:border-box;box-sizing:border-box;font-size:13px;line-height:21px;color:#333;height:100%}',
                    upperStr +='\n.ly_pop .tx_desc em{text-decoration:underline}',
                    upperStr +='\n.ly_pop .tx_in{display:block}',
                    upperStr +='\n.ly_pop .tx_card{font-size:13px}',
                    upperStr +='\n.ly_pop .btn_area{display:-webkit-box;display:flex;-webkit-box-sizing:border-box;box-sizing:border-box;position:absolute;top:auto;bottom:0;right:0;left:0;width:auto;height:55px;margin:0;padding:0 10px;background:none}',
                    upperStr +='\n.ly_pop .btn_area a{display:-webkit-box;display:flex;-webkit-box-flex:1;flex:1;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;-webkit-box-sizing:border-box;box-sizing:border-box;overflow:hidden;width:100%;height:45px;margin-left:4px;padding:1px 0 0;background:#1e1e1e;font-weight:bold;font-size:15px;color:#fff;line-height:45px;text-align:center;text-decoration:none}',
                    upperStr +='\n.ly_pop .btn_area a:first-child{margin-left:0}',
                    upperStr +='\n.ly_pop .btn_area .btn_update{background:#fa2828}';
            }
        }
        function dbStr(bl) {
            if(bl){
                upperStr +='\n/* 맞춤쿠폰 DB연동 관련 (아이템 템플릿) */'
                upperStr +='\n.item_template{padding:20px 25px 35px;background-color:#fff}',
                    upperStr +='\n.group_notice{padding:13px 19px 12px;border:1px solid #bfbfbf}',
                    upperStr +='\n.group_notice .bx_tit{margin-bottom:5px;font-size:0}',
                    upperStr +='\n.group_notice .ico_notice{display:inline-block;width:12px;height:12px;margin:2px 2px 0 0 ;background-image:url(https://image.toast.com/aaaaac/paycoNoti/ico_notice.png);background-size:100% auto;vertical-align:middle}',
                    upperStr +='\n.group_notice .tit_txt{display:inline-block;font-size:13px;font-weight:bold;color:#000;line-height:19px;letter-spacing:-.5px;vertical-align:middle}',
                    upperStr +='\n.group_notice .txt{font-size:12px;line-height:16px;letter-spacing:-.5px;color:#666}',
                    upperStr +='\n.group_notice + .bx_filter{margin-top:32px}',
                    upperStr +='\n.group_notice .txt li{position: relative;padding-left:10px}',
                    upperStr +="\n.group_notice .txt li:before{display:inline-block;position: absolute;top:7px;left:1px;content:'';width:2px;height:2px;background:#4b4a38}",
                    upperStr +='\n.bx_filter{position:relative;margin-top:16px}'
                upperStr +='\n.bx_filter .txt{display:block;font-size:13px;color:#000;}'
                upperStr +='\n.bx_filter .txt_deco{font-weight:bold;color:#ff2828}'
                upperStr +="\n.bx_filter .txt_deco .count{font-family:'Roboto'}"
                upperStr +='\n.bx_filter .lst_filter{position:absolute;top:-1px;right:-13px;font-size:0}'
                upperStr +='\n.bx_filter .lst_filter li{display:inline-block;position:relative;vertical-align:top}'
                upperStr +="\n.bx_filter .lst_filter li:before{position:absolute;top:50%;left:0;width:1px;height:13px;margin-top:-6px;background-color:#bbb;content:''}"
                upperStr +='\n.bx_filter .lst_filter li:first-child:before{display:none}'
                upperStr +='\n.bx_filter .lst_filter li.on .btn_option{color:#000}'
                upperStr +='\n.bx_filter .lst_filter .btn_option{display:block;padding:3px 13px;font-size:13px;line-height:17px;color:#666}'
                upperStr +='\n.bx_filter + .lst_item_type{margin-top:-11px}'
                upperStr +='\n.lst_item_type{margin:0 0 0 -1.5%}'
                upperStr +="\n.lst_item_type:after{display:block;clear:both;content:''}"
                upperStr +='\n.lst_item_type li{float:left;width:48.485%;margin:27px 0 0 1.5%}'
                upperStr +='\n.lst_item_type li:nth-child(odd){clear:both}'
                upperStr +='\n.lst_item_type .item_link{display:block;position:relative}'
                upperStr +='\n.lst_item_type .tag{display:block;position:absolute;top:0;left:0;width:35px;height:20px;font-size:0;background-image:url(https://image.toast.com/aaaaac/paycoNoti/ico_new.png);background-size:100% auto}'
                upperStr +='\n.lst_item_type .bx_img{display:block;background-color:#ececec}'
                upperStr +='\n.lst_item_type .bx_img img{display:block;width:100%;height:100%}'
                upperStr +='\n.lst_item_type .item_info{margin-top:7px;font-size:0}'
                upperStr +='\n.lst_item_type .item_info .name{display:-webkit-box;overflow:hidden;max-height:32px;margin-bottom:5px;padding-left:2px;padding-right:8px;font-size:12px;line-height:16px;color:#000;word-break:break-all;-webkit-box-orient:vertical;-webkit-line-clamp:2;text-overflow:ellipsis}'
                upperStr +="\n.lst_item_type .item_info .price{display:inline-block;margin-right:3px;padding-left:3px;font-family:'Roboto';font-size:17px;line-height:21px;letter-spacing:0;color:#000;vertical-align:top}"
                upperStr +='\n.lst_item_type .item_info .price.sale{font-weight:bold;font-size:18px;vertical-align: middle}'
                upperStr +='\n.lst_item_type .item_info .price.original{padding-left:2px;font-size:12px;line-height:16px;color:#bbb;text-decoration:line-through;vertical-align: middle}'
                upperStr +="\n.lst_item_type .item_info .price .unit{font-family:'Noto Sans KR','Apple SD Gothic Neo',sans-serif;font-weight:normal}"
            }
            else {

            }
        }

        //date
        var date = new Date();
        var dd = date.getDate();
        if(dd<10){
            var dd = '0' + String(dd);
        }
        else{
            var dd = String(dd);
        }
        var mm = date.getMonth()+1;
        if(mm<10){
            var mm = '0' + String(mm);
        }
        else{
            var mm = String(mm);
        }
        var yy = date.getFullYear();
        var yy = String(yy);
        var yy = yy.substring(2,4);
        var today = yy+mm+dd;

        //section
        var cn = 0;
        var ln = 0;
        for (i=0;i<secNum+1;i++){
            var ii = i + 1;
            var cc = $('#couponNum'+ii).val();
            var ll = $('#linkNum'+ii).val();
            var upperStr = upperStr;
            if(i == 0){
                var sec = 'header';
                var dn = cn;
                cn = Number(cn) + Number(cc);
                var mn = ln;
                ln = Number(ln) + Number(ll);
            }
            else if(i == secNum){
                //템플릿 위치
                if(templateType == 0) {
                    if(booleanDb) {
                        if(fixedType == 0) {
                            dbSection($('#dbAlert').val(), $('#advCode').val(), 'rate='+$('#dbRate').val()+'|max='+$('#dbMax').val(), '');
                        }
                        else {
                            dbSection($('#dbAlert').val(), $('#advCode').val(), '', $('#dbSetting').val());
                        }
                    }
                    upperStr += '\n	<div class="sec sec_noti">',
                        upperStr += '\n 		<h3 class="tit">이벤트 유의사항</h3>',
                        upperStr += '\n 		<ul class="lst_noti">';
                    upperStr += '\n 		<li></li>';
                    upperStr += '\n 		<li></li>';
                    upperStr += '\n 		<li></li>';
                    upperStr += '\n 		<li></li>';
                    upperStr += '\n 		<li></li>';
                    upperStr += '\n 		<li></li>';
                    upperStr += '\n		</ul>',
                        upperStr += '\n	</div>',
                        upperStr += '\n</div>',
                        upperStr += '\n</div>',
                        upperStr += '\n<!--//이벤트 영역-->';
                    break;
                }
                else {
                    if(booleanDb) {
                        if(fixedType == 0) {
                            dbSection($('#dbAlert').val(), $('#advCode').val(), 'rate='+$('#dbRate').val()+'|max='+$('#dbMax').val(), '');
                        }
                        else {
                            dbSection($('#dbAlert').val(), $('#advCode').val(), '', $('#dbSetting').val());
                        }
                    }
                    templateHtml(templateType, templateTypeOnline, templateTypeOffline);
                    templateBtn(promoType);
                    break;
                }
            }
            else if(i == 1){
                var sec = 'img';
                var dn = cn;
                cn = Number(cn) + Number(cc);
                var mn = ln;
                ln = Number(ln) + Number(ll);
            }
            else{
                var sec = 'img' + i;
                var dn = cn;
                cn = Number(cn) + Number(cc);
                var mn = ln;
                ln = Number(ln) + Number(ll);
            }

            function noti(nt){
                for(a=0;a<nt;a++){
                    upperStr += '\n			<li></li>';
                    if(a == nt){
                        break;
                    }
                }
            }
            upperStr += '\n	<div class="sec">',
                upperStr += '\n		<div class="blind">',
                upperStr += '\n		</div>';
            if(promoType == 0){
                if(couponType == 0){
                    coupon(0,false,false);
                }
                else{
                    coupon(cc,promoType,ii);
                }
                if(minType == 0){
                    linkUrl(0,ll,ii);
                }
                else{
                    linkUrl(1,ll,ii);
                }
            }
            else{
                if(minType == 0){
                    coupon(cc,promoType,ii);
                    linkUrl(0,ll,ii);
                }
                else{
                    coupon(cc,promoType,ii);
                    linkUrl(2,ll,ii);
                }
            }
            upperStr += '\n		<img src="'+srcType+'/evt_m'+promoName+'_'+sec+'_'+today+'.jpg" width="100%" alt="">',
                upperStr += '\n	</div>';
        };
        function templateHtml(tT,tTOn,tTOff) {
            upperStr += '\n	<div class="sec sec_guide">',
                upperStr += '\n		<div class="tit_wrap">',
                upperStr += '\n			<h3 class="tit">이용방법</h3>',
                upperStr += '\n		</div>',
                upperStr += '\n		<ol class="lst_guide">';
            if (tT == 1) {
                templateGuideA(tTOn);
            }
            else if (tT == 2) {
                templateGuideB(tTOff);
            }
            upperStr += '\n		</ol>';
        }
        function templateGuideA(gA) {
            var ment1 = '쿠폰 다운로드하기',
                ment2 = '가맹점에서 결제 시, 결제 수단으로 [PAYCO] 선택하기',
                ment3 = templateBrand+'에서 쿠폰번호 등록하기',
                ment4 = '쿠폰번호 복사 후, 결제 시 쿠폰코드 입력하기',
                ment5 = '결제 시, 결제 수단으로 [PAYCO] 선택하기',
                ment6 = '쿠폰 적용 후, 결제하기',
                ment7 = '결제 시, 쿠폰 사용하기',
                ment8 = '혜택 적용 사항 확인 후 결제하기';
            switch(gA) {
                case "0":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment2+'</li>',
                        upperStr += '\n			<li>3. '+ment6+'</li>';
                    break;
                case "1":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment3+'</li>',
                        upperStr += '\n			<li>3. '+ment7+'</li>';
                    break;
                case "2":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment4+'</li>',
                        upperStr += '\n			<li>3. '+ment6+'</li>';
                    break;
                case "3":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment5+'</li>',
                        upperStr += '\n			<li>3. '+ment6+'</li>';
                    break;
                case "4":
                    upperStr += '\n			<li>1. '+ment5+'</li>',
                        upperStr += '\n			<li>2. '+ment8+'</li>';
                    break;
                default:
                    break;
            }
        }
        function templateGuideB(gB) {
            var ment1 = '쿠폰 다운로드하기',
                ment2 = '매장 방문하기',
                ment3 = '매장 방문 후, 계산 시 직원에게 쿠폰 보여주기',
                ment4 = '매장 방문 후, PAYCO 앱으로 결제하기',
                ment5 = '키오스크 결제 시 [PAYCO 앱 → QR코드] 실행',
                ment6 = 'PAYCO 앱으로 결제하기',
                ment7 = '키오스크에서 PAYCO 앱으로 결제',
                ment8 = '직원,키오스크를 통해 PAYCO 앱으로 결제하기',
                ment9 = '할인 적용된 금액을 PAYCO로 결제하기',
                ment10 = '할인 적용 금액 확인 후, 현금/카드 결제',
                ment11 = '결제 완료 (결제 시 할인 자동 적용)',
                ment12 = '키오스크에서 쿠폰 사용하기',
                ment13 = '직원 또는 키오스크를 통해 쿠폰 사용하기',
                ment14 = '매장 방문 후, 직원에게 쿠폰 보여주기',
                ment15 = '결제 완료 (할인 자동 적용)';
            switch(gB) {
                case "0":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment3+'</li>',
                        upperStr += '\n			<li>3. '+ment9+'</li>';
                    break;
                case "1":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment3+'</li>',
                        upperStr += '\n			<li>3. '+ment10+'</li>';
                    break;
                case "2":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment4+'</li>',
                        upperStr += '\n			<li>3. '+ment11+'</li>';
                    break;
                case "3":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment2+'</li>',
                        upperStr += '\n			<li>3. '+ment12+'</li>';
                    break;
                case "4":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment2+'</li>',
                        upperStr += '\n			<li>3. '+ment13+'</li>';
                    break;
                case "5":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment14+'</li>';
                    break;
                case "6":
                    upperStr += '\n			<li>1. '+ment1+'</li>',
                        upperStr += '\n			<li>2. '+ment5+'</li>',
                        upperStr += '\n			<li>3. '+ment11+'</li>';
                    break;
                case "7":
                    upperStr += '\n			<li>1. '+ment2+'</li>',
                        upperStr += '\n			<li>2. '+ment6+'</li>',
                        upperStr += '\n			<li>3. '+ment11+'</li>';
                    break;
                case "8":
                    upperStr += '\n			<li>1. '+ment2+'</li>',
                        upperStr += '\n			<li>2. '+ment4+'</li>',
                        upperStr += '\n			<li>3. '+ment15+'</li>';
                    break;
                case "9":
                    upperStr += '\n			<li>1. '+ment2+'</li>',
                        upperStr += '\n			<li>2. '+ment8+'</li>',
                        upperStr += '\n			<li>3. '+ment15+'</li>';
                    break;
                default:
                    break;
            }
        }
        function templateBtn(aa){

            if($('#templateBtn1').is(':checked')) {
                if(promoType == 0) {
                    upperStr += '\n		<a href="payco://open/mycoupon" class="btn btn_type2">받은 쿠폰 확인하기</a>';
                }
                else {
                    upperStr += '\n		<a href="http://ad-network.payco.com/views/coupons" class="btn btn_type2">받은 쿠폰 확인하기</a>';
                }
            }
            if($('#templateBtn2').is(':checked')) {
                var templateClient = $('#templateBtnStore').val();
                templateClient = templateClient.replace(/ /gi,"");
                if(minType == 0) {
                    upperStr += '\n		<a href="'+templateClient+'" class="btn btn_type2">가까운 매장찾기</a>';
                }
                else if(minType == 1) {
                    if(promoType == 0) {
                        var templateClient = String(templateClient);
                        var templateClientPayco = templateClient.substring(0,8);
                        if(templateClientPayco == 'payco://') {
                            upperStr += '\n		<a href="'+templateClient+'" class="btn btn_type2">가까운 매장찾기</a>';
                        }
                        else {
                            upperStr += '\n		<a href="payco://event?detail='+templateClient+'" class="btn btn_type2">가까운 매장찾기</a>';
                        }
                    }
                    else if(promoType == 1) {
                        upperStr += '\n		<a href="'+templateClient+'" class="btn btn_type2" target="_blank" rel="noopener noreferrer">가까운 매장찾기</a>';
                    }
                }
            }
            if($('#templateBtn3').is(':checked')) {
                var templateUrl = $('#templateBtnUrl').val();
                templateUrl = templateUrl.replace(/ /gi,"");
                var templateTxt = $('#templateBtnClient').val();
                var templateColor = $('#templateBtnColor').val();
                var templateBtnClass = 'btn';
                if(templateColor == ''){
                    templateBtnClass = 'btn';
                }
                else {
                    templateBtnClass = 'btn btn_color4';
                }
                if(minType == 0) {
                    upperStr += '\n		<a href="'+templateUrl+'" class="'+templateBtnClass+'">'+templateTxt+'</a>';
                }
                else if(minType == 1) {
                    if(promoType == 0) {
                        var templateUrl = String(templateUrl);
                        var templateUrlPayco = templateUrl.substring(0,8);
                        if(templateUrlPayco == 'payco://') {
                            upperStr += '\n		<a href="'+templateUrl+'" class="'+templateBtnClass+'">'+templateTxt+'</a>';
                        }
                        else {
                            upperStr += '\n		<a href="payco://event?detail='+templateUrl+'" class="'+templateBtnClass+'">'+templateTxt+'</a>';
                        }
                    }
                    else if(promoType == 1) {
                        upperStr += '\n		<a href="'+templateUrl+'" class="'+templateBtnClass+'" target="_blank" rel="noopener noreferrer">'+templateTxt+'</a>';
                    }
                }
            }
            if($('#templateBtn4').is(':checked')) {
                upperStr += '\n		<a href="payco://open/offline/main" class="btn btn_qrcode">오프라인 결제</a>';
            }
            if($('#templateBtn5').is(':checked')) {
                upperStr += '\n		<a href="payco://open/offline/main" class="btn btn_barcode">오프라인 결제</a>';
            }
            upperStr += '\n	</div>';
            upperStr += '\n 	<div class="sec sec_noti">';
            upperStr += '\n 		<h3 class="tit">이벤트 유의사항</h3>';
            upperStr += '\n 		<ul class="lst_noti">';
            upperStr += '\n 		<li></li>';
            upperStr += '\n 		<li></li>';
            upperStr += '\n 		<li></li>';
            upperStr += '\n 		<li></li>';
            upperStr += '\n 		<li></li>';
            upperStr += '\n 		<li></li>';
            upperStr += '\n		</ul>';
            upperStr += '\n	</div>';
            upperStr += '\n</div>';
            upperStr += '\n</div>';
            upperStr += '\n<!--//이벤트 영역-->';
        }
        function coupon(n,nn,m){
            if(nn == 0){
                for(t=0;t<n;t++){
                    var tt = t + 1;
                    var tt2 = Number(dn) + Number(tt);
                    if(tt2 == 1){
                        var tt2 = '';
                    }
                    else{
                        var tt2 = tt2;
                    }
                    var pi = $('#prmtId_'+m+'_'+tt).val();
                    var ci = $('#couponId_'+m+'_'+tt).val();
                    var ct = $('#couponTxt_'+m+'_'+tt).val();
                    if(pi==''){
                        upperStr += '\n 		<a href="javascript:;" class="btn btn_coupon'+tt2+' btn_couponDown" couponId="'+ci+'"><span class="blind">'+ct+'</span></a>';
                    }
                    else {
                        upperStr += '\n 		<a href="javascript:;" class="btn btn_coupon'+tt2+' btn_couponDown" prmtId="'+pi+'" couponId="'+ci+'"><span class="blind">'+ct+'</span></a>';
                    }
                    if(t == n){
                        break;
                    }
                }
            }
            else if(nn == 1){
                for(t=0;t<n;t++){
                    var tt = t + 1;
                    var tt2 = Number(dn) + Number(tt);
                    if(tt2 == 1){
                        var tt2 = '';
                    }
                    else{
                        var tt2 = tt2;
                    }
                    var ci = $('#couponId_'+m+'_'+tt).val();
                    var ct = $('#couponTxt_'+m+'_'+tt).val();
                    upperStr += '\n 		<a href="javascript:;" class="btn btn_coupon'+tt2+' btn_couponDown" couponId="'+ci+'"><span class="blind">'+ct+'</span></a>';
                    if(t == n){
                        break;
                    }
                }
            }
        }
        function linkUrl(nn,m,ss){
            if(nn == 0){
                for(s=0;s<m;s++){
                    var zz = s + 1;
                    var zz2 = Number(mn) + Number(zz);
                    if(zz2 == 1){
                        var zz2 = '';
                    }
                    else{
                        var zz2 = zz2
                    }
                    var url = $('#url_'+ss+'_'+zz).val();
                    url = url.replace(/ /gi,"");
                    var lnkTxt = $('#lnkTxt_'+ss+'_'+zz).val();
                    upperStr += '\n 		<a href="'+url+'" class="btn btn_link'+zz2+'"><span class="blind">'+lnkTxt+'</span></a>';
                    if(s == m){
                        break;
                    }
                }
            }
            else if(nn == 1){
                for(s=0;s<m;s++){
                    var zz = s + 1;
                    var zz2 = Number(mn) + Number(zz);
                    if(zz2 == 1){
                        var zz2 = '';
                    }
                    else{
                        var zz2 = zz2
                    }
                    var url = $('#url_'+ss+'_'+zz).val();
                    url = url.replace(/ /gi,"");
                    var lnkTxt = $('#lnkTxt_'+ss+'_'+zz).val();
                    var u = url.substring(0,8);
                    if(u == 'payco://'){
                        upperStr += '\n 		<a href="'+url+'" class="btn btn_link'+zz2+'"><span class="blind">'+lnkTxt+'</span></a>';
                        if(s == m){
                            break;
                        }
                    }
                    else{
                        upperStr += '\n 		<a href="payco://event?detail='+url+'" class="btn btn_link'+zz2+'"><span class="blind">'+lnkTxt+'</span></a>';
                        if(s == m){
                            break;
                        }
                    }
                }
            }
            else if(nn == 2){
                for(s=0;s<m;s++){
                    var zz = s + 1;
                    var zz2 = Number(mn) + Number(zz);
                    if(zz2 == 1){
                        var zz2 = '';
                    }
                    else{
                        var zz2 = zz2
                    }
                    var url = $('#url_'+ss+'_'+zz).val();
                    url = url.replace(/ /gi,"");
                    var lnkTxt = $('#lnkTxt_'+ss+'_'+zz).val();
                    upperStr += '\n 		<a href="'+url+'" class="btn btn_link'+zz2+'" target="_blank" rel="noopener noreferrer"><span class="blind">'+lnkTxt+'</span></a>';
                    if(s == m){
                        break;
                    }
                }
            }
        }
        function dbSection(dbAlertText,aCode,fixedRate,fixedPrice) {
            upperStr +='\n	<div class="sec item_template">',
                upperStr +='\n		<div class="group_notice">',
                upperStr +='\n			<div class="bx_tit">',
                upperStr +='\n				<span class="ico_notice"><span class="blind">알림</span></span>',
                upperStr +='\n				<em class="tit_txt">알려드립니다</em>',
                upperStr +='\n			</div>',
                upperStr +='\n			<p class="txt">'+dbAlertText+'</p>',
                upperStr +='\n		</div>',
                upperStr +='\n		<div class="bx_filter" pageCount="8" isAble="Y" categ="" pageNum="1" advCode="'+aCode+'" fixedRate="'+fixedRate+'" fixedPrice="'+fixedPrice+'">',
                upperStr +='\n			<em class="txt">총 <span class="txt_deco"><span class="count" id="shopzone_count">0</span>개</span> 상품</em>',
                upperStr +='\n			<!-- [D] 활성화 된 옵션 : li 에 on 클래스 추가 -->',
                upperStr +='\n			<ul class="lst_filter">',
                upperStr +='\n			<li '+filterOn[0]+'categ="NEW" id="shopzone_new"'+filterDisplay[0]+'><button type="button" class="btn_option">최신순</button></li>',
                upperStr +='\n			<li '+filterOn[1]+'categ="BEST" id="shopzone_best"'+filterDisplay[1]+'><button type="button" class="btn_option">인기순</button></li>',
                upperStr +='\n			<li '+filterOn[2]+'categ="GENERAL" id="shopzone_general"'+filterDisplay[2]+'><button type="button" class="btn_option">일반순</button></li>',
                upperStr +='\n			</ul>',
                upperStr +='\n		</div>',
                upperStr +='\n		<ul class="lst_item_type"></ul>',
                upperStr +='\n	</div>'

        }

        //couponSetting
        if(couponType == 0){
            if(minType == 0){
                upperStr +='\n',
                    upperStr +='\n',
                    upperStr +='\n</div>',
                    upperStr +='\n</div>',
                    upperStr +='\n',
                    upperStr +='\n</div>',
                    upperStr +='\n</div>',
                    upperStr +='\n</body>',
                    upperStr +='\n</html>';
            }
            else if(minType == 2){
                upperStr +='\n',
                    upperStr +='\n';
            }
        }
        if(couponType == 1){
            upperStr +='\n',
                upperStr +='\n<!-- 일반쿠폰 레이어팝업 --> <!-- [D] 레이어 팝업(쿠폰 다운로드 프로모션): 각 레이어 ID로 버튼 연결 -->',
                upperStr +='\n<div class="dimmed" style="display:none"></div>',
                upperStr +='\n',
                upperStr +='\n<div id="COUPON_ISSUED_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">쿠폰 발급 성공!</span></h2>';
            if (minType == 0){
                lowerStr(false,0);
            }
            else if(minType){
                lowerStr(false,1);
            }

        }
        if(couponType == 2){
            upperStr +='\n',
                upperStr +='\n<!-- 선착순 쿠폰 레이어팝업 --> <!-- [D] 레이어 팝업(쿠폰 다운로드 프로모션): 각 레이어 ID로 버튼 연결 -->',
                upperStr +='\n<div class="dimmed" style="display:none"></div>',
                upperStr +='\n',
                upperStr +='\n<div id="COUPON_ISSUED_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">선착순 쿠폰 발급 성공!</span></h2>';
            if (minType == 0){
                lowerStr(false,0);
            }
            else if(minType){
                lowerStr(false,1);
            }
        }
        if(couponType == 3){
            upperStr +='\n',
                upperStr +='\n<!-- 일선착순 쿠폰 레이어팝업 --> <!-- [D] 레이어 팝업(쿠폰 다운로드 프로모션): 각 레이어 ID로 버튼 연결 -->',
                upperStr +='\n<div class="dimmed" style="display:none"></div>',
                upperStr +='\n',
                upperStr +='\n<div id="COUPON_ISSUED_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">선착순 쿠폰 발급 성공!</span></h2>';
            if (minType == 0){
                lowerStr(1,0);
            }
            else if(minType){
                lowerStr(1,1);
            }
        }
        function lowerStr(il,ii){
            upperStr +='\n			<div class="tx_desc"><span class="tx_in"><em>메뉴 &gt; 받은 쿠폰</em>에서<br>확인 할 수 있습니다.</span></div>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_mycoupon">쿠폰함으로 이동</a>',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="COUPON_ALREADY_ISSUED_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">쿠폰을 이미<br>발급 받으셨습니다.</span></h2>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="UserIssueLimitCountFail_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">쿠폰을 이미<br>발급 받으셨습니다</span></h2>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="COUPON_ALREADY_USED_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">쿠폰을 사용하셨습니다.</span></h2>',
                upperStr +='\n			<div class="tx_desc"><span class="tx_in">본 쿠폰은 기간 내 한 번만<br>사용할 수 있습니다.</span></div>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="COUPON_BURNOUT_POP_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">쿠폰이 모두 소진되었습니다.</span></h2>',
                upperStr +='\n			<div class="tx_desc"><span class="tx_in">더 좋은 이벤트로 찾아 뵙겠습니다.</span></div>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="NOT_CERTIFICATED_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">본인인증이 필요합니다.</span></h2>',
                upperStr +='\n			<div class="tx_desc"><span class="tx_in"><em>메뉴 &gt; 회원정보관리</em>에서<br>본인인증을 진행해주세요.</span></div>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="NOT_TARGET_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">이벤트 대상자가 아닙니다.</span></h2>',
                upperStr +='\n			<div class="tx_desc"><span class="tx_in"><em>더 좋은 이벤트로 찾아 뵙겠습니다.</em></span></div>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="END_EVENT_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">종료된 이벤트 입니다.</span></h2>',
                upperStr +='\n			<div class="tx_desc"><span class="tx_in"><em>더 좋은 이벤트로 찾아 뵙겠습니다.</em></span></div>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="NOT_APP_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">잘못된 접근 입니다.</span></h2>',
                upperStr +='\n			<div class="tx_desc"><span class="tx_in"><em>페이코 앱을 통해 접속해주세요.</em></span></div>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                upperStr +='\n			</div>',
                upperStr +='\n		</div>',
                upperStr +='\n	</div>',
                upperStr +='\n</div>',
                upperStr +='\n<div id="ISSUE_FAILED_ly_pop" class="ly_pop" style="display:none">',
                upperStr +='\n	<div class="ly_popbx">',
                upperStr +='\n		<div class="ly_popin">',
                upperStr +='\n			<h2><span class="ly_tit">쿠폰을 발급하지 못했습니다.</span></h2>',
                upperStr +='\n			<div class="tx_desc"><span class="tx_in"><em id="failed_message">발급 실패 코드 : </em></span></div>',
                upperStr +='\n			<div class="btn_area">',
                upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
            upperStr +='\n			</div>',
            upperStr +='\n		</div>',
            upperStr +='\n	</div>',
            upperStr +='\n</div>',
            upperStr +='\n<div id="PROMOTION_NOT_IN_STOCK_ly_pop" class="ly_pop" style="display:none">',
            upperStr +='\n	<div class="ly_popbx">',
            upperStr +='\n		<div class="ly_popin">',
            upperStr +='\n			<h2><span class="ly_tit">쿠폰이 모두 소진되었습니다.</span></h2>',
            upperStr +='\n			<div class="tx_desc"><span class="tx_in">더 좋은 이벤트로 찾아 뵙겠습니다.</span></div>',
            upperStr +='\n			<div class="btn_area">',
            upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
            upperStr +='\n			</div>',
            upperStr +='\n		</div>',
            upperStr +='\n	</div>',
            upperStr +='\n</div>',
            upperStr +='\n<div id="OverIssueEndYmdt_ly_pop" class="ly_pop" style="display:none">',
            upperStr +='\n	<div class="ly_popbx">',
            upperStr +='\n		<div class="ly_popin">',
            upperStr +='\n			<h2><span class="ly_tit">쿠폰이 모두 소진되었습니다.</span></h2>',
            upperStr +='\n			<div class="tx_desc"><span class="tx_in">더 좋은 이벤트로 찾아 뵙겠습니다.</span></div>',
            upperStr +='\n			<div class="btn_area">',
            upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
            upperStr +='\n			</div>',
            upperStr +='\n		</div>',
            upperStr +='\n	</div>',
            upperStr +='\n</div>';
            if(il == 1){
                upperStr +='\n<div id="COUPON_DAILY_BURNOUT_ly_pop" class="ly_pop" style="display:none">',
                    upperStr +='\n	<div class="ly_popbx">',
                    upperStr +='\n		<div class="ly_popin">',
                    upperStr +='\n			<h2><span class="ly_tit">쿠폰이 모두 소진되었습니다.</span></h2>',
                    upperStr +='\n			<div class="tx_desc"><span class="tx_in">금일 준비된 수량이 모두 소진되었습니다. 내일 다시 확인해 주세요.</span></div>',
                    upperStr +='\n			<div class="btn_area">',
                    upperStr +='\n				<a href="#" class="btn_ok">확인</a>',
                    upperStr +='\n			</div>',
                    upperStr +='\n		</div>',
                    upperStr +='\n	</div>',
                    upperStr +='\n</div>';
            }
            else{}
            upperStr +='\n',
                upperStr +='\n',
                upperStr +='\n<div id="case_view" style="display:none;overflow:hidden;position:fixed;bottom:0;right:0;left:0;z-index:9999;height:auto;padding:5px;background:#000;opacity:0.6;text-align:right">',
                upperStr +='\n	<a href="#" id="COUPON_ISSUED" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">쿠폰 발급</a>',
                upperStr +='\n	<a href="#" id="COUPON_ALREADY_ISSUED" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">이미받은 쿠폰</a>',
                upperStr +='\n	<a href="#" id="UserIssueLimitCountFail" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">쿠폰중복 다운로드</a>',
                upperStr +='\n	<a href="#" id="COUPON_ALREADY_USED" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">이미 쿠폰사용</a>',
                upperStr +='\n	<a href="#" id="COUPON_BURNOUT_POP" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">쿠폰소진</a>',
                upperStr +='\n	<a href="#" id="NOT_CERTIFICATED" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">본인인증</a>',
                upperStr +='\n	<a href="#" id="END_EVENT" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">종료된 프로모션</a>',
                upperStr +='\n	<a href="#" id="NOT_TARGET" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">다른이벤트</a>',
                upperStr +='\n	<a href="#" id="NOT_APP" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">앱이 아님</a>',
                upperStr +='\n	<a href="#" id="COUPON_BURNOUT" style="display:inline-block;padding:5px;background:red;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">전 수량 소진</a>',
                upperStr +='\n	<a href="#" id="INVALID_ACCESS" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">유효하지 않은 접근</a>',
                upperStr +='\n	<a href="#" id="NOT_LATEST_VERSION" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">업데이트</a>',
                upperStr +='\n	<a href="#" id="NEED_INSTALL_APP" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">앱설치 안내</a>',
                upperStr +='\n	<a href="#" id="LOGIN_GUIDE" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">로그인 안내</a>',
                upperStr +='\n	<a href="#" id="NOT_MEMBERSHIP_TARGET" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">멤버십타겟</a>',
                upperStr +='\n	<a href="#" id="PROMOTION_NOT_IN_STOCK" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">쿠폰소진</a>',
                upperStr +='\n   <a href="#" id="OverIssueEndYmdt" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">쿠폰소진</a>';
            if(il == 1){
                upperStr +='\n   <a href="#" id="COUPON_DAILY_BURNOUT" style="display:inline-block;padding:5px;background:#212121;font-size:13px;font-weight:bold;color:#fff;text-decoration:none">금일 수량 만료</a>';
            }
            else{}
            upperStr +='\n</div>',
                upperStr +='\n<!-- //레이어팝업 -->',
                upperStr +='\n',
                upperStr +="\n<!-- '확인' 클릭 시 내쿠폰함 이동 스크립트 (필요한 경우만 사용) -->",
                upperStr +='\n<script>',
                upperStr +='\n$(function(){',
                upperStr +='\n	$("#COUPON_ISSUED_ly_pop .btn_mycoupon").click(function(e){',
                upperStr +='\n		location.href = "payco://open/mycoupon";',
                upperStr +='\n	});',
                upperStr +='\n});',
                upperStr +='\n</'+'script>';
            if(ii == 0){
                upperStr +='\n',
                    upperStr +='\n',
                    upperStr +='\n</div>',
                    upperStr +='\n</div>',
                    upperStr +='\n',
                    upperStr +='\n</div>',
                    upperStr +='\n</div>',
                    upperStr +='\n</body>',
                    upperStr +='\n</html>';
            }
            else if (ii == 1){
                upperStr +='\n',
                    upperStr +='\n',
                    upperStr +='\n</div>',
                    upperStr +='\n</div>',
                    upperStr +='\n',
                    upperStr +='\n</div>',
                    upperStr +='\n</div>';
            }

        }
        var promoName = $('#promotion_name').val();
        $('.codeview').text(upperStr);
        if(minType == 0) {
            $('.download').hide();
            $('#htmlDown').show();
        }
        else{
            $('.download').hide();
            $('#minDown').show();
        }
    });
    function downloadInnerHtml(elementid, filename, mimeType, extension) {
        var elHtml = $(elementid).text();
        var link = document.createElement('a');
        link.setAttribute('download', filename + extension);
        link.setAttribute('href', 'data:' + mimeType  +  ';charset=utf-8,' + encodeURIComponent(elHtml));
        link.click();
    }
    $('#htmlDown').click(function(){
        downloadInnerHtml(codeview,'event','txt/html','.html');
    });
    $('#minDown').click(function(){
        downloadInnerHtml(codeview,'event.min','txt/html','.html');
    });
});